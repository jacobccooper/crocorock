##This is based on Cooper, JC 2018. doi:10.1111/jav.01771

filepath="~/Crocorock-Tutorial/Data-for-Tutorial/Woodpecker"

setwd(filepath)

#'Declare required packages
#'Make sure these packages are preinstalled!
#'Use the command 'install.packages()'

library(ggplot2)

#Data Cleaning

##Reducing the filesize

setwd(filepath)
wp=read.csv("allwoodpecker_nov16_colreduced_REVISION.csv")
print("Displaying portion of file: downloaded specimen data")
wp[1:5,c(1,2,4,8,9)]

#Change scientific names of mislabeled species
unique(wp[wp$Species=='pubescens',12])
wp[wp$Species=='pubescens',12]="Picoides"
unique(wp[wp$Species=='villosus',12])
wp[wp$Species=='villosus',12]="Picoides"

#Reduce file to species of interest
wp2=wp[which(wp$Genus=='Picoides'|wp$Genus=='Campephilus'|wp$Genus=='Dryocopus'),]
sps=(print(as.character(unique(wp2$Species))))
sps=sps[order(sps)]
sps2=sps[-c(1:7,12,13,15,16,18,19,21:24,28:32)]
a=NULL
for(i in 1:length(sps2)){
  sps3=sps2[i]
  a=c(a,which(wp2$Species==sps3))
}

wp3=wp2[a,]
write.csv(wp3,"StudySpecies.csv",quote=F,row.names=F)

wp3=read.csv("StudySpecies.csv")

summary(wp3$Species)

wp4=wp3[-which(wp3$Species=='galeatus'|wp3$Species=='gayaquilensis'|wp3$Species=='haematogaster'|wp3$Species=='leucopogon'|wp3$Species=='pollens'|wp3$Species=='robustus'),]
write.csv(wp4,'StudyTaxa_reduced.csv',quote=F,row.names=F)

#'Remove outliers
#'Ensure that we have more accurate datapoints

wp=read.csv("StudyTaxa_reduced.csv")
y=as.character(unique(wp$Species))
for(i in 1:length(y)){
  s.wp=wp[which(wp$Species==y[i]),]
  wp=wp[-(which(wp$Species==y[i])),]
  m.s=mean(s.wp$Mass.g)
  sd.s=sd(s.wp$Mass.g)
  rem.s=s.wp[which(s.wp$Mass.g>(m.s-(2*sd.s)) & s.wp$Mass.g<(m.s+(2*sd.s))),]
  wp=rbind(wp,rem.s)
}

#'Remove juveniles
#'Remove birds that are abnormally small or large
#'These birds are potentially misidentified

wp=wp[-which(wp$Mass.g<10),]
wp=wp[-which(wp$Species=='pubescens'&wp$Mass.g>40),]
wp=wp[-which(wp$Institution=="KU"&wp$CatalogNo==95783),]
wp=wp[-which(wp$Age=='Juvenile'),]
write.csv(wp,'StudyTaxa_refined.csv',quote=F,row.names=F)

##Spatial and Temporal Accuracy

#'Edit data based on year

x1=unique(wp$Year)
x2=order(x1)
#All unique years
print(x1[x2])

wpq=wp[which(wp$Year!=8888&wp$Year>1800),]

mode=function(x){
  xx=unique(x)
  xx[which.max(tabulate(match(x,xx)))]
}

#'Most commonly collected year
mode(wpq$Year)
#'Histogram of year collected
#'qplot(wpq$Year,geom="histogram")

#'Analyze spatial precision

#Summary of Coordinate Accuracy in KM
length(na.omit(wp$Coordinate.Uncertainty.M))/length(wp$Coordinate.Uncertainty.M)
summary((wp$Coordinate.Uncertainty.M/1000))
#hist((wp$Coordinate.Uncertainty.M/1000))
#Summary of Coordinate Precision in KM
summary(wp$Coordinate.Precision.M/1000)

#How many points have an accuracy of 25 km or less?
#1-length(which((wp$Coordinate.Uncertainty.M/1000)>=25))/nrow(wp)

#96.3%

summary(wp[which((wp$Coordinate.Uncertainty.M/1000)>=25),13])

#Points removed are from small woodpeckers

wp=wp[-which((wp$Coordinate.Uncertainty.M/1000)>=25),]
summary(wp$Coordinate.Uncertainty.M/1000)
write.csv(wp,'StudyTaxa_refined-accurate.csv',quote=F,row.names=F)

#'Which wordclim dataset should be used?
#'Find which set overlaps with most of the observations

y=unique(wp$Species)
for(i in 1:length(y)){
ysp=y[i]
print(paste0("Values for ",ysp))
print(summary(wp[which(wp$Species==ysp),10]))
print(paste0("Min year: ",min(wpq[which(wpq$Species==ysp),5]),
", Max year: ",max(wpq[which(wpq$Species==ysp),5])))
}

years=as.numeric(wpq$Year)

ny=length(years)
ny2=length(years[which(years>=1960&years<=1990)])
ny.b=length(years[which(years<1960)])
ny.a=length(years[which(years>1990)])

ny3=length(years[which(years>=1970&years<=2000)])

print(paste0("Percentage in WORLDCLIM 1.4 time period: ",round(ny2/ny,2)))
print(paste0("Percentage in WORLDCLIM 2.0 time period: ",round(ny3/ny,2)))
print(paste0("Percentage before 1991: ",round(1-(ny.a/ny),2)))

##Data Preparation

#'I removed a section on geographic variation

#Clear up internal memory by removing what we don't need

#Clear internal memory
wp=read.csv('Edited-Woodpecker-Data.csv')
a=ls()
a=a[-(which(a=="filepath"|a=="wp"))]
rm(list=a)

bcpicx=which(wp$Genus=='Picoides')
pico=wp[bcpicx,]

#'Create and save plot of masses by geographic area
#'This cannot be viewed on the server but can be imported
#'Use the command SCP!

a=ggplot(aes(x=as.factor(bcpic),y=Mass.g,fill=Species),data=pico)
b=geom_boxplot()
c=coord_flip()
d=theme_classic()
d.1=theme(axis.title = element_text(face="bold",size=20),
          axis.text = element_text(size=10,face="bold"),
          legend.title = element_blank(),
          legend.text = element_text(size=14,face="bold"))
e=labs(x='BCR',y='Mass in grams')
fig1=a+b+c+d+d.1+e

ggsave("Figure2.jpg",fig1,dpi=400)

#'Testing masses by component 1

pico$Mass.g=as.numeric(pico$Mass.g)

pico$bio11=pico$bio11*-1

#'ANCOVA analyses of relationships

pico3=as.data.frame(pico)                 #using ANCOVA directly

aa1=aov(Mass.g~Lat,data=pico3)
summary(aa1)
aa2=aov(Mass.g~Species,data=pico3)
summary(aa2)

mod1=aov(Mass.g~Lat*Species,data=pico3)   #sig. effect of both, sig. interaction
#Therefore, slope is different and intercept is different (see following)
summary(mod1)

mod2=aov(Mass.g~Lat+Species,data=pico3)   #significant difference in intercepts
summary(mod2)

mod3=aov(Mass.g~Lat:Species,data=pico3)   #so different slopes?
summary(mod3)

anova(mod1,mod2)                          #removing interaction significantly affects

eq.x.1=lm(pico3[which(pico3$Species=='pubescens'),]$Mass~(pico3[which(pico3$Species=='pubescens'),]$Lat))
a.1.1=round(coef(eq.x.1)[1],2)#intercept
b.1.1=round(coef(eq.x.1)[2],2)#slope
r.x.1=round(summary(eq.x.1)$r.squared,2)
a.err.1=round(summary(eq.x.1)$coefficients[3],2)
b.err.1=round(summary(eq.x.1)$coefficients[4],2)

eq.x=lm(pico3[which(pico3$Species=='villosus'),]$Mass~pico3[which(pico3$Species=='villosus'),]$Lat)
a.1=round(coef(eq.x)[1],2)#intercept
b.1=round(coef(eq.x)[2],2)#slope
r.x=round(summary(eq.x)$r.squared,2)
a.err=round(summary(eq.x)$coefficients[3],2)
b.err=round(summary(eq.x)$coefficients[4],2)

a=ggplot(aes(x=(as.numeric(Lat)),y=as.numeric(Mass.g),color=Species),data=pico3)
b=geom_point()
c=geom_smooth(method=lm)
d=theme_classic()
d.1=theme(axis.title = element_text(face="bold",size=20),
          axis.text = element_text(size=10,face="bold"),
          legend.title = element_blank(),
          legend.text = element_text(size=14,face="bold"))

e=labs(x='Latitude',y='Mass in grams')
#p=annotate("text",label=paste0('P. pubescens: y=(',b.1.1,'x +/- ',2*b.err.1,') + (',a.1.1," +/- ",2*a.err.1,')',', r^2 = ',r.x.1),x=0,y=100)
#p.1=annotate("text",label=paste0('P. villosus: y=(',b.1,'x +/- ',2*b.err,') + (',a.1," +/- ",2*a.err,')',', r^2 = ',r.x),x=0,y=90)
Fig3=a+b+c+d+e+d.1

ggsave("Figure4.jpg",Fig3,dpi=400)

#'End of tutorial script
#'Look up paper for more tests that can be performed on these data